# Test-dummy-para-creadores-de-UGC
Eres un creador de UGC y de accesorios?Pues este modelo te servira!Esto lo podras medir para tus accesorios creados,lo malo es que los colores no cargan al darle a jugar en roblox studio,pero vale la pena,

Este modelo es para todos!Puedes hacerle lo que quieras!este modelo es un archivo .rbxm


-yosoyteo67

Debes que arrastrar el archivo .rbxm a la pantalla de roblox studio o insertar modelos desde el apartado de MODELO
